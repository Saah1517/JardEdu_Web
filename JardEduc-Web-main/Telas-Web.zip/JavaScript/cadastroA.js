
//Senha e Confirmar senha
var password = document.getElementById("password")
var confirm_password = document.getElementById("confirm_password");

function validatePassword(){
if(password.value != confirm_password.value) {
  confirm_password.setCustomValidity("Senhas diferentes!");
} else {
  confirm_password.setCustomValidity('');
}
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;


//Nome do Aluno
let inputNome = document.querySelector("#nomeAluno");
inputNome.addEventListener("keydown", function(e) {  
  if (e.key >= "0" && e.key <= "9") {
    e.preventDefault();
  }
});

//Nome Do respunsavel
let inputNome2 = document.querySelector("#nameResp");
inputNome2.addEventListener("keydown", function(e) {  
  if (e.key >= "0" && e.key <= "9") {
    e.preventDefault();
  }
});
